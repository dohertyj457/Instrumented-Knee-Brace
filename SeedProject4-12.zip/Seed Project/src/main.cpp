#include <Arduino.h>

#include <Wire.h>
#include <SPI.h>
#include <SD.h>
#include <Adafruit_MPU6050.h>

File myFile;
uint32_t myTime;
int SDPin = 10;
const int MPU_ADDR1 = 0b1101000; // IMU I2C - differentiated using the AD0 pin set HIGH or LOW
const int MPU_ADDR2 = 0b1101001; // (AD0 = 0, 1101000. AD0 = 1, 1101001)

//IMU1 = AD0 LOW, IMU2 = AD0 HIGH

//Establishing variables for values that will be recorded and stored
float setData [18];
//allData[0]-allData[6]: t1, aX1, aY1, aZ1, gyroX1, gyroY1, gyroZ1
//allData[7]-allData[13]: t2, aX2, aY2, aZ2, gyroX2, gyroY2, gyroZ2
//allData[14]-allData[17]: t3, POT, EMG1, EMG2

float allData [108]; //6x sets, can try to increase in intervals of 18
//THE NUMBER ON THE VARIABLE CORRESPONDS TO THE SENSOR:
// t1= TIME IMU1 DATA WERE TAKEN
// t2 = TIME IMU 2 DATA WERE TAKEN
//t3 = TIME BOTH EMG SIGNALS WERE TAKEN


float gyroX; float gyroY; float gyroZ; float aX; float aY; float aZ;

//FUNCTIONS: I was getting errors without establishing functions here...
void setupMPU();
void setupSD();
void recordAccel1(int sensor);
void recordGyro1(int sensor);
void recordAccel2(int sensor);
void recordGyro2(int sensor);
void emgSig1(int vPin);
void emgSig2(int vPin);
void writeIMU();
void writeEMG();
//void write2SD();
void getPot();

//-----SETUP-----
void setup() {
  // put your setup code here, to run once:
  Serial.begin(500000);
  Wire.begin();
  setupMPU();
  setupSD();
}

//-----LOOP-----
void loop() {
  int setCount = 0;
  int dataCount = 0;
  //Each setCount loop is one recording from every sensor, and associated timestamps
  // upper setCount value = allData/setData
  while (setCount < 6){
    setData[0] = millis();
    recordAccel1(MPU_ADDR1);
    recordGyro1(MPU_ADDR1);
    setData[7] = millis();
    recordAccel2(MPU_ADDR2);
    recordGyro2(MPU_ADDR2);
    setData[14] = millis();
    getPot();
    emgSig1(A1);
    emgSig2(A2);
    for(int i = 0;  i<18; i++){
      allData[dataCount] = setData[i];
      dataCount++;
    }
    setCount++;
  }
  //Printing to Serial:
  //CHANGE UPPER i WITH SIZE OF allData (sizeof function gives bytes not elements)
  for(int i = 0; i < 108; i++){
    if (i % 18==0) {
      Serial.println();
    }
      Serial.print(allData[i]);
      Serial.print(" ");
  }
  //void write2SD();
  //delay(3);
}


//Functions called above_______________________________________________________________________

//SETUP FUNCTIONS__
void setRegister (int sens, int reg, int regset){
  // Begin coms with sensor, access required register, set desired values
  Wire.beginTransmission(sens); //I2C address
  Wire.write(reg); //Accesses register 
  Wire.write(regset); //Sets register
  Wire.endTransmission();
}

void setupMPU(){
  // Use setRegister function to wake up sensors and set data collection frequencies
  setRegister(MPU_ADDR1,0x6B,0b00000000); //Register 6B - Power Management - Wakes up IMU
  setRegister(MPU_ADDR2,0x6B,0b00000000);
  setRegister(MPU_ADDR1,0x1B,0x00000000); //Register 1B - Gyroscope - sets gyro outputs to +- 250 degrees per second
  setRegister(MPU_ADDR2,0x1B,0x00000000);
  setRegister(MPU_ADDR1,0x1C,0x00000000); //Register 1C - Accelerometer - sets accelerometer outputs to +-2g
  setRegister(MPU_ADDR2,0x1C,0x00000000);
}

void setupSD(){
  //Establishes connection with SD reader
  Serial.println("Attempting to set up SD card");
  while (!Serial) { // wait for serial port to connect. Needed for native USB port only
    }
  Serial.print("Initializing SD card...");
  if (!SD.begin(SDPin)) {
  Serial.println("initialization failed!");
  while (1);
  }
  Serial.println("initialization done."); 
}

//DATA COLLECTION FUNCTIONS___

void recordAccel1(int sensor){
  //Serial.println("Now I'm in here");
  //records accel values in x,y,z directions from one sensor
  
  Wire.beginTransmission(sensor); //I2C Address
  Wire.write(0x3B); //Register 3B - Accelerometer readings
  Wire.endTransmission();
  //Serial.println("Still working?");
  Wire.requestFrom(sensor,6); //Reads from registers 3B-40
  while(Wire.available() < 6);
  float aX = Wire.read()<<8|Wire.read(); //first 2 bytes = ax
  float aY = Wire.read()<<8|Wire.read(); //second 2 bytes = ay
  float aZ = Wire.read()<<8|Wire.read(); //last 2 bytes = az
  //Serial.println("STILL working?");
  // Must be processed: based on Accelerometer register settings
  setData[1] = aX/16384;
  setData[2] = aY/16384;
  setData[3] = aZ/16384;
}

void recordGyro1(int sensor){
  // 
  Wire.beginTransmission(sensor); //I2C Address
  Wire.write(0x43); //Register 43
  Wire.endTransmission();
  Wire.requestFrom(sensor,6); //Reads from registers 3B-40
  while(Wire.available() < 6);
  float gyroX = Wire.read()<<8|Wire.read(); //first 2 bytes = gx
  float gyroY = Wire.read()<<8|Wire.read(); //second 2 bytes =gy
  float gyroZ = Wire.read()<<8|Wire.read(); //last 2 bytes = gz
  setData[4] = gyroX/131;
  setData[5] = gyroY/131;
  setData[6] = gyroZ/131;

}
void recordAccel2(int sensor){
  //records accel values in x,y,z directions from one sensor
  
  Wire.beginTransmission(sensor); //I2C Address
  Wire.write(0x3B); //Register 3B - Accelerometer readings
  Wire.endTransmission();
  Wire.requestFrom(sensor,6); //Reads from registers 3B-40
  while(Wire.available() < 6);
  float aX = Wire.read()<<8|Wire.read(); //first 2 bytes = ax
  float aY = Wire.read()<<8|Wire.read(); //second 2 bytes = ay
  float aZ = Wire.read()<<8|Wire.read(); //last 2 bytes = az
  // Must be processed: based on Accelerometer register settings
  setData[8] = aX/16384;
  setData[9] = aY/16384;
  setData[10] = aZ/16384;
}


void recordGyro2(int sensor){
  // 
  Wire.beginTransmission(sensor); //I2C Address
  Wire.write(0x43); //Register 43
  Wire.endTransmission();
  Wire.requestFrom(sensor,6); //Reads from registers 3B-40
  while(Wire.available() < 6);
  float gyroX = Wire.read()<<8|Wire.read(); //first 2 bytes = gx
  float gyroY = Wire.read()<<8|Wire.read(); //second 2 bytes =gy
  float gyroZ = Wire.read()<<8|Wire.read(); //last 2 bytes = gz

  setData[11] = gyroX/131;
  setData[12] = gyroY/131;
  setData[13] = gyroZ/131;

}

void getPot(){
  //potentiometer
  long sensorValue = analogRead(A0);
  //map() scales data to the range of the analog out - analogRead range from 0 to 1023 (original range) and analogWrite range from 0 to 255 (new range) 
  //allData[14] = map(sensorValue,0,1023,0,255);
  setData[15] = sensorValue;
  // print out the value you read:
  //Serial.println(pot);
  // delay(10);    
}
void emgSig1(int vPin){
  //emg
  float sensorValue = analogRead(vPin);
  float voltage = sensorValue;//*(5.0/1024.0); 
  setData[16] = voltage;
}

void emgSig2(int vPin){
  //emg
  float sensorValue = analogRead(vPin);
  float voltage = sensorValue;//*(5.0/1024.0);
  setData[17] = voltage;
}

void write2SD(){
  //print data onto SD Module
  myFile = SD.open("test.txt", O_CREAT | O_WRITE);
  // if the file opened okay, write to it:
  if (myFile) {
    for(int i = 0; i < 108; i++){
    if (i % 18==0) {
      myFile.println();
    }
      myFile.print(allData[i]);
      myFile.print(" ");
  }
  // //close the file:
  myFile.close();
  }
  else {
  //if the file didn't open, print an error:
  Serial.println("error opening test.txt");
  }
}

void writeEMG(){
  //print data onto SD Module
  myFile = SD.open("EMGtest.txt", FILE_WRITE);
  // if the file opened okay, write to it:
  if (myFile) {
    for(int i = 14; i < 17; i++)
    {
      myFile.print(setData[i]);
      myFile.print(" ");
    }
    myFile.println();
  //close the file:
    myFile.close();
  }
  else {
  //if the file didn't open, print an error:
    Serial.println("error opening test.txt");
  }
}