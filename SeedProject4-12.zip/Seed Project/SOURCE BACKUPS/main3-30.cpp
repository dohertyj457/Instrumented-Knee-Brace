#include <Arduino.h>

#include <Wire.h>
#include <SPI.h>
#include <SD.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_MPU6050.h>

File myFile;
uint32_t myTime;
int SDPin = 10;
const int MPU_ADDR1 = 0b1101000; // IMU I2C - differentiated using the AD0 pin set HIGH or LOW
const int MPU_ADDR2 = 0b1101001; // (AD0 = 0, 1101000. AD0 = 1, 1101001)

//IMU1 = AD0 LOW, IMU2 = AD0 HIGH

//Establishing variables for values that will be recorded and stored
long allData [18];
//THE NUMBER ON THE VARIABLE CORRESPONDS TO THE SENSOR:
// t1= TIME IMU1 DATA WERE TAKEN
// t2 = TIME IMU 2 DATA WERE TAKEN
//t3 = TIME BOTH EMG SIGNALS WERE TAKEN
//allData[0]-allData[6]: t1, aX1, aY1, aZ1, gyroX1, gyroY1, gyroZ1
//allData[7]-allData[14]: t2, aX2, aY2, aZ2, gyroX2, gyroY2, gyroZ2, POT
//allData[15]-allData[17]: t3, EMG1, EMG2

long gyroX; long gyroY; long gyroZ; long aX; long aY; long aZ; long POT;

//FUNCTIONS: I was getting errors without establishing functions here...
void setupMPU();
void setupSD();
void recordAccel1(int sensor);
void recordGyro1(int sensor);
void recordAccel2(int sensor);
void recordGyro2(int sensor);
void emgSig1(int vPin);
void emgSig2(int vPin);
void writeIMU();
void writeEMG();
void GetPot();

//-----SETUP-----
void setup() {
  Serial.println('Starting void setup.');
  // put your setup code here, to run once:
  Serial.begin(500000);
  Wire.begin();
  Serial.println("In setup.");
  setupMPU();
  setupSD();
  Serial.println("Setup complete.");
}

//-----LOOP-----
void loop() {
  Serial.println('Starting void loop.');
  allData[0] = millis();
  recordAccel1(MPU_ADDR1);
  recordGyro1(MPU_ADDR1);
  allData[7] = millis();
  recordAccel2(MPU_ADDR2);
  recordGyro2(MPU_ADDR2);
  GetPot();
  allData[15] = millis();
  emgSig1(A1);
  emgSig2(A2);
  for(int i = 0; i < 18; i++){
      Serial.print(allData[i]);
      Serial.print(" ");
  }
  Serial.println();
  //writeIMU();
  //writeEMG();
  //delay(3);
}


//Functions called above_______________________________________________________________________

//SETUP FUNCTIONS__
void setRegister (int sens, int reg, int regset){
  // Begin coms with sensor, access required register, set desired values
  Wire.beginTransmission(sens); //I2C address
  Wire.write(reg); //Accesses register 
  Wire.write(regset); //Sets register
  Wire.endTransmission();
}

void setupMPU(){
  // Use setRegister function to wake up sensors and set data collection frequencies
  setRegister(MPU_ADDR1,0x6B,0b00000000); //Register 6B - Power Management - Wakes up IMU
  setRegister(MPU_ADDR2,0x6B,0b00000000);
  setRegister(MPU_ADDR1,0x1B,0x00000000); //Register 1B - Gyroscope - sets gyro outputs to +- 250 degrees per second
  setRegister(MPU_ADDR2,0x1B,0x00000000);
  setRegister(MPU_ADDR1,0x1C,0x00000000); //Register 1C - Accelerometer - sets accelerometer outputs to +-2g
  setRegister(MPU_ADDR2,0x1C,0x00000000);
}

void setupSD(){
  //Establishes connection with SD reader
  Serial.println("Attempting to set up SD card");
  while (!Serial) { // wait for serial port to connect. Needed for native USB port only
    }
  Serial.print("Initializing SD card...");
  if (!SD.begin(SDPin)) {
  Serial.println("initialization failed!");
  while (1);
  }
  Serial.println("initialization done."); 
}

//DATA COLLECTION FUNCTIONS___

void recordAccel1(int sensor){
  //Serial.println("Now I'm in here");
  //records accel values in x,y,z directions from one sensor
  
  Wire.beginTransmission(sensor); //I2C Address
  Wire.write(0x3B); //Register 3B - Accelerometer readings
  Wire.endTransmission();
  //Serial.println("Still working?");
  Wire.requestFrom(sensor,6); //Reads from registers 3B-40
  while(Wire.available() < 6);
  int aX = Wire.read()<<8|Wire.read(); //first 2 bytes = ax
  int aY = Wire.read()<<8|Wire.read(); //second 2 bytes = ay
  int aZ = Wire.read()<<8|Wire.read(); //last 2 bytes = az
  //Serial.println("STILL working?");
  // Must be processed: based on Accelerometer register settings
  allData[1] = aX/16384;
  allData[2] = aY/16384;
  allData[3] = aZ/16384;
}

void recordGyro1(int sensor){
  // 
  Wire.beginTransmission(sensor); //I2C Address
  Wire.write(0x43); //Register 43
  Wire.endTransmission();
  Wire.requestFrom(sensor,6); //Reads from registers 3B-40
  while(Wire.available() < 6);
  int gyroX = Wire.read()<<8|Wire.read(); //first 2 bytes = gx
  int gyroY = Wire.read()<<8|Wire.read(); //second 2 bytes =gy
  int gyroZ = Wire.read()<<8|Wire.read(); //last 2 bytes = gz
  allData[4] = gyroX/131;
  allData[5] = gyroY/131;
  allData[6] = gyroZ/131;

}
void recordAccel2(int sensor){
  //records accel values in x,y,z directions from one sensor
  
  Wire.beginTransmission(sensor); //I2C Address
  Wire.write(0x3B); //Register 3B - Accelerometer readings
  Wire.endTransmission();
  Wire.requestFrom(sensor,6); //Reads from registers 3B-40
  while(Wire.available() < 6);
  int aX = Wire.read()<<8|Wire.read(); //first 2 bytes = ax
  int aY = Wire.read()<<8|Wire.read(); //second 2 bytes = ay
  int aZ = Wire.read()<<8|Wire.read(); //last 2 bytes = az
  // Must be processed: based on Accelerometer register settings
  allData[8] = aX/16384;
  allData[9] = aY/16384;
  allData[10] = aZ/16384;
}


void recordGyro2(int sensor){
  // 
  Wire.beginTransmission(sensor); //I2C Address
  Wire.write(0x43); //Register 43
  Wire.endTransmission();
  Wire.requestFrom(sensor,6); //Reads from registers 3B-40
  while(Wire.available() < 6);
  int gyroX = Wire.read()<<8|Wire.read(); //first 2 bytes = gx
  int gyroY = Wire.read()<<8|Wire.read(); //second 2 bytes =gy
  int gyroZ = Wire.read()<<8|Wire.read(); //last 2 bytes = gz

  allData[11] = gyroX/131;
  allData[12] = gyroY/131;
  allData[13] = gyroZ/131;

}

void GetPot(){
  //potentiometer
  long sensorValue = analogRead(A0);
  //map() scales data to the range of the analog out - analogRead range from 0 to 1023 (original range) and analogWrite range from 0 to 255 (new range) 
  //allData[14] = map(sensorValue,0,1023,0,255);
  allData[14] = sensorValue;
  // print out the value you read:
  //Serial.println(pot);
  // delay(10);    
  ;
}

void emgSig1(int vPin){
  //emg
  int sensorValue = analogRead(vPin);
  float voltage = sensorValue;//*(5.0/1024.0); 
  allData[15] = voltage;
}

void emgSig2(int vPin){
  //emg
  int sensorValue = analogRead(vPin);
  float voltage = sensorValue;//*(5.0/1024.0);
  allData[16] = voltage;
}

void writeIMU(){
  //print data onto SD Module
  myFile = SD.open("IMUtest.txt", O_CREAT | O_WRITE);
  // if the file opened okay, write to it:
  //Serial.print("In the IMU File"):
  if (myFile) {
    //Serial.print("In the for loop")
    for(int i = 0; i < 14; i++){
      myFile.print(allData[i]);
      myFile.print(" ");
    }
    myFile.println();
  // //close the file:
    myFile.close();
  }
  else {
  //if the file didn't open, print an error:
  Serial.println("error opening test.txt");
  }
}

void writeEMG(){
  //print data onto SD Module
  myFile = SD.open("EMGtest.txt", O_CREAT | O_WRITE);
  // if the file opened okay, write to it:
  if (myFile) {
    for(int i = 15; i < 18; i++)
    {
      myFile.print(allData[i]);
      myFile.print(" ");
    }
    myFile.println();
  //close the file:
    myFile.close();
  }
  else {
  //if the file didn't open, print an error:
    Serial.println("error opening test.txt");
  }
}