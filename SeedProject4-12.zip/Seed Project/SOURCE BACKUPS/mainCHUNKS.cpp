#include <Arduino.h>

#include <Wire.h>
#include <SPI.h>
#include <SD.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_MPU6050.h>

File myFile;
float myTime;
int SDPin = 10;
const int MPU_ADDR1 = 0b1101000; // IMU I2C - differentiated using the AD0 pin set HIGH or LOW
const int MPU_ADDR2 = 0b1101001; // (AD0 = 0, 1101000. AD0 = 1, 1101001)

//IMU1 = AD0 LOW, IMU2 = AD0 HIGH

//Establishing variables for values that will be recorded and stored
long allData [234]; //going to be saving 13 sets (described below) at a time
long setData [18];


//THE NUMBER ON THE VARIABLE CORRESPONDS TO THE SENSOR:
// t1= TIME IMU1 DATA WERE TAKEN
// t2 = TIME IMU 2 DATA WERE TAKEN
//t3 = TIME BOTH EMG SIGNALS WERE TAKEN
//allData[0]-allData[6]: t1, aX1, aY1, aZ1, gyroX1, gyroY1, gyroZ1
//allData[7]-allData[14]: t2, aX2, aY2, aZ2, gyroX2, gyroY2, gyroZ2, POT
//allData[15]-allData[17]: t3, EMG1, EMG2

float gyroX; float gyroY; float gyroZ; float aX; float aY; float aZ; float POT;

//FUNCTIONS: I was getting errors without establishing functions here...
void setRegister(int sens, int reg, int regset);
void setupMPU();
void setupSD();
void recordAccel1(int sensor);
void recordGyro1(int sensor);
void recordAccel2(int sensor);
void recordGyro2(int sensor);
void emgSig1(int vPin);
void emgSig2(int vPin);
void collectData();
void writeIMU();
void writeEMG();
void writeItAll();
void GetPot();

//-----SETUP-----
void setup() {
  // put your setup code here, to run once:
  Serial.begin(500000);
  //Serial.print("setup longer message in case this is going unnoticed somehow");
  Wire.begin();
  //Serial.print("MPU setup...");
  setupMPU();
  //Serial.print("SD setup...");
  setupSD();
  
}

//-----LOOP-----
void loop() {
  collectData();
  Serial.println("Data collected");
//This for loop will print data in serial instead of on the SD card
  for(int i = 0; i < 234; i++){
    Serial.println("In the for loop");
    if (i % 18==0) {
      Serial.println("In the if statement");
      Serial.println();
    }
      Serial.print(allData[i]);
      Serial.print(" ");
      
  }

  //writeIMU();
  //writeEMG();
  //writeItAll();
  //delay(3);
}


//Functions called above_______________________________________________________________________

//SETUP FUNCTIONS__
void setRegister (int sens, int reg, int regset){
  // Begin coms with sensor, access required register, set desired values
  Wire.beginTransmission(sens); //I2C address
  Wire.write(reg); //Accesses register 
  Wire.write(regset); //Sets register
  Wire.endTransmission();
}

void setupMPU(){
  // Use setRegister function to wake up sensors and set data collection frequencies
  setRegister(MPU_ADDR1,0x6B,0b00000000); //Register 6B - Power Management - Wakes up IMU
  setRegister(MPU_ADDR2,0x6B,0b00000000);
  setRegister(MPU_ADDR1,0x1B,0x00000000); //Register 1B - Gyroscope - sets gyro outputs to +- 250 degrees per second
  setRegister(MPU_ADDR2,0x1B,0x00000000);
  setRegister(MPU_ADDR1,0x1C,0x00000000); //Register 1C - Accelerometer - sets accelerometer outputs to +-2g
  setRegister(MPU_ADDR2,0x1C,0x00000000);
}

void setupSD(){
  //Establishes connection with SD reader
  Serial.println("Attempting to set up SD card");
  while (!Serial) { // wait for serial port to connect. Needed for native USB port only
    }
  Serial.print("Initializing SD card...");
  if (!SD.begin(SDPin)) {
  Serial.println("initialization failed!");
  while (1);
  }
  Serial.println("initialization done."); 
}

//DATA COLLECTION FUNCTIONS___

void recordAccel1(int sensor){
  //Serial.println("Now I'm in here");
  //records accel values in x,y,z directions from one sensor
  
  Wire.beginTransmission(sensor); //I2C Address
  Wire.write(0x3B); //Register 3B - Accelerometer readings
  Wire.endTransmission();
  //Serial.println("Still working?");
  Wire.requestFrom(sensor,6); //Reads from registers 3B-40
  while(Wire.available() < 6);
  aX = Wire.read()<<8|Wire.read(); //first 2 bytes = ax
  aY = Wire.read()<<8|Wire.read(); //second 2 bytes = ay
  aZ = Wire.read()<<8|Wire.read(); //last 2 bytes = az
  //Serial.println("STILL working?");
  // Must be processed: based on Accelerometer register settings
  setData[1] = aX/16384;
  setData[2] = aY/16384;
  setData[3] = aZ/16384;
}

void recordGyro1(int sensor){
  // 
  Wire.beginTransmission(sensor); //I2C Address
  Wire.write(0x43); //Register 43
  Wire.endTransmission();
  Wire.requestFrom(sensor,6); //Reads from registers 3B-40
  while(Wire.available() < 6);
  gyroX = Wire.read()<<8|Wire.read(); //first 2 bytes = gx
  gyroY = Wire.read()<<8|Wire.read(); //second 2 bytes =gy
  gyroZ = Wire.read()<<8|Wire.read(); //last 2 bytes = gz
  setData[4] = gyroX/131;
  setData[5] = gyroY/131;
  setData[6] = gyroZ/131;

}
void recordAccel2(int sensor){
  //records accel values in x,y,z directions from one sensor
  
  Wire.beginTransmission(sensor); //I2C Address
  Wire.write(0x3B); //Register 3B - Accelerometer readings
  Wire.endTransmission();
  Wire.requestFrom(sensor,6); //Reads from registers 3B-40
  while(Wire.available() < 6);
  aX = Wire.read()<<8|Wire.read(); //first 2 bytes = ax
  aY = Wire.read()<<8|Wire.read(); //second 2 bytes = ay
  aZ = Wire.read()<<8|Wire.read(); //last 2 bytes = az
  // Must be processed: based on Accelerometer register settings
  setData[8] = aX/16384;
  setData[9] = aY/16384;
  setData[10] = aZ/16384;
}


void recordGyro2(int sensor){
  // 
  Wire.beginTransmission(sensor); //I2C Address
  Wire.write(0x43); //Register 43
  Wire.endTransmission();
  Wire.requestFrom(sensor,6); //Reads from registers 3B-40
  while(Wire.available() < 6);
  gyroX = Wire.read()<<8|Wire.read(); //first 2 bytes = gx
  gyroY = Wire.read()<<8|Wire.read(); //second 2 bytes =gy
  gyroZ = Wire.read()<<8|Wire.read(); //last 2 bytes = gz

  setData[11] = gyroX/131;
  setData[12] = gyroY/131;
  setData[13] = gyroZ/131;

}

void GetPot(){
  //potentiometer
  long sensorValue = analogRead(A0);
  //map() scales data to the range of the analog out - analogRead range from 0 to 1023 (original range) and analogWrite range from 0 to 255 (new range) 
  //allData[14] = map(sensorValue,0,1023,0,255);
  setData[15] = sensorValue;
  // print out the value you read:
  //Serial.println(pot);
  // delay(10);    
}

void emgSig1(int vPin){
  //emg
  int sensorValue = analogRead(vPin);
  float voltage = sensorValue;//*(5.0/1024.0); 
  setData[16] = voltage;
}

void emgSig2(int vPin){
  //emg
  int sensorValue = analogRead(vPin);
  float voltage = sensorValue;//*(5.0/1024.0);
  setData[17] = voltage;
}


// Data Manipulation/Writing Functions
void collectData(){
  Serial.println("in collectData");
  int setCount = 0;
  int dataCount = 0;
  while (setCount < 13){
    Serial.println("in While loop");
    setData[0] = millis();
    recordAccel1(MPU_ADDR1); //~100 Hz Min
    recordGyro1(MPU_ADDR1);
    setData[7] = millis();
    recordAccel2(MPU_ADDR2);
    recordGyro2(MPU_ADDR2);
    setData[14] = millis();
    GetPot(); //Only need ~25-50 Hz
    emgSig1(A1); // Preferably 250 Hz
    emgSig2(A2);
    for(int i = 0;  i<17; i++){
      allData[dataCount] = setData[i];
      dataCount+=1;
    }
    setCount+=1;
  }
}

void writeIMU(){
  //print data onto SD Module
  myFile = SD.open("IMU.txt", O_CREAT | O_WRITE);
  // if the file opened okay, write to it:
  //Serial.print("In the IMU File"):
  if (myFile) {
    //Serial.print("In the for loop")
    for(int i = 0; i < 13; i++){
      myFile.print(allData[i]);
      myFile.print(" ");
    }
    myFile.println();
  // //close the file:
    myFile.close();
  }
  else {
  //if the file didn't open, print an error:
  Serial.println("error opening test.txt");
  }
}

void writeEMG(){
  //print data onto SD Module
  myFile = SD.open("EMG.txt", O_CREAT | O_WRITE);
  // if the file opened okay, write to it:
  if (myFile) {
    for(int i = 13; i < 17; i++)
    {
      myFile.print(allData[i]);
      myFile.print(" ");
    }
    myFile.println();
  //close the file:
    myFile.close();
  }
  else {
  //if the file didn't open, print an error:
   // Serial.println("error opening test.txt");
  }
}

void writeItAll(){
  //print data onto SD Module
  myFile = SD.open("Data.txt", O_CREAT | O_WRITE);
  // if the file opened okay, write to it:
  //Serial.print("In the IMU File"):
  if (myFile) {
    //Serial.print("In the for loop")
    for(int i = 0; i < 17; i++){
      myFile.print(allData[i]);
      myFile.print(" ");
    }
    myFile.println();
  // //close the file:
    myFile.close();
  }
  else {
  //if the file didn't open, print an error:
  //Serial.println("error opening test.txt");
  }
}
